package car;

public enum TypeBody {
    SUV,
    SEDAN,
    PICUP,
    COUPE,
    HATCHBACK,
    MINIVAN,
    CARGO_VAN,
    CONVERTIBLE
}
