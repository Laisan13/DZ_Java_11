package car;

public class AutoPlant {
    //1.2 Создайте второй класс в том же пакете, в котором
    // будет создаваться первый класс (например, класс Университет для класса Студент
    // или класс Завод для класса автомобиль).
    // Внутри класса определите метод, который создаёт
    // объект первого класса и присвоите ему те поля, которые возможно.

    public Plant manufacturer;
    private  Car car;
    private Store color;

    public Plant getManufacturer() {
        return manufacturer;
    }

    public void setManufacturer(Plant manufacturer) {
        this.manufacturer = manufacturer;
    }

    public AutoPlant(int year, TypeBody typeBody,float engineDisplacement, Plant manufacturer, Store color) {
        Car car = new Car();
        car.setYear(year);
        car.setTypeBody(typeBody);
        car.setEngineDisplacement(engineDisplacement);
        this.color = color;
        this.car = car;
        this.manufacturer = manufacturer;
    }














}
