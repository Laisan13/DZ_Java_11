package car;
//1 Создайте Package (ПКМ на папке src -> New -> Package).
//1.1 В созданном пакете создайте класс с минимум 3мя полями для одного из объектов
// реального мира (студент, батарейка, автомобиль…).
// Одно из полей сделайте публичным, второе – без модификатора доступа,
// остальные – приватными. Создайте объект этого класса в программе и
// попробуйте установить значения для полей. Какие поля возможно установить?

import java.awt.*;

public class Car {
    public TypeBody typeBody;//типы кузова
    private int year;// год выпуска
    float engineDisplacement; //объем двигателя 1–1,2 литра; 1,2–1,6 литра; 1,6–2 литра; 2–2,5 литра; от 2 л и больше.



    //1.4 Реализуйте геттеры и сеттеры для класса 1.

    public TypeBody getTypeBody() {
        return typeBody;
    }

    public void setTypeBody(TypeBody typeBody) {
        this.typeBody = typeBody;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public float getEngineDisplacement() {
        return engineDisplacement;
    }

    public void setEngineDisplacement(float engineDisplacement) {
        this.engineDisplacement = engineDisplacement;
    }
    //1.3 Напишите минимум 2 конструктора для класса 1.

    public Car(TypeBody typeBody) {
        this.typeBody = typeBody;

    }

    public Car(TypeBody typeBody, int year, float engineDisplacement) {
        this(typeBody);
        this.year = year;
        this.engineDisplacement = engineDisplacement;

    }



    //1.5 Создайте другие методы для класса.
    public Car(){

    }

    public static String choiceCar (Car car){
        return " Тип кузова " + car.typeBody + " год выпуска " + car.year + " Объем  двигателя "+ car.engineDisplacement;
    }

    public void statusBay() {
        System.out.println("Благодарим за выбор нашего магазина");
    }



    //1.7 Добавьте клонирующий конструктор к классу 1.
    // В программе склонируйте созданный ранее объект. Проверьте с помощью ==,
    // что объекты имеют разные ссылки в памяти.
    // Затем измените объект класса 3, который лежит внутри оригинального объекта класса 1.8
    // С помощью == сравните ссылочные поля оригинала и клона. Вложенные объекты имеют одинаковую ссылку в памяти?
    public Car(Car original){
        this(original.typeBody);
        this.engineDisplacement = original.engineDisplacement;
        this.year = original.year;
    }





}






