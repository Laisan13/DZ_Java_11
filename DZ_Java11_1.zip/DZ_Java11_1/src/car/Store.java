package car;

import java.awt.*;

public class Store {
    public Color color;//Цвет машины

    public Color getColor() {
        return color;
    }

    public void setColor(Color color) {
        this.color = color;
    }
}
